<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

function getDiscordUsername($userId, $token) {
    $discordApiUrl = "https://discord.com/api/users/$userId";
    $options = [
        "http" => [
            "header" => "Authorization: Bot $token\r\n"
        ]
    ];
    $context = stream_context_create($options);
    $response = file_get_contents($discordApiUrl, false, $context);

    if ($response) {
        $data = json_decode($response, true);
        return $data['username'] ?? 'Desconhecido';
    } else {
        return 'Desconhecido';
    }
}

if (isset($_GET['userid'])) {
    $userId = $_GET['userid'];
    $token = 'MTI1NDI2MzExNDYxOTE2MjczNA.Ga2YhE.BCeBSC4Fn9OhjHZlA1etQ1GFjo0RiHHJst89hM'; // Substitua pelo seu token de acesso do Discord

    $username = getDiscordUsername($userId, $token);
    echo json_encode(['username' => $username]);
} else {
    echo json_encode(['error' => 'ID do usuário não fornecido.']);
}
?>


