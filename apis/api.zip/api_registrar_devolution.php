<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

$servername = "legendarycommunity.com.br"; 
$username = "apis";
$password = "PO6u68GalIz5Picec33inuLEjA8O72"; 
$dbname = "minecraft"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $userid = isset($_POST['userid']) ? $_POST['userid'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $print = isset($_POST['print']) ? $_POST['print'] : '';
    $id_ticket = isset($_POST['id_ticket']) ? $_POST['id_ticket'] : '';
    $descricao = isset($_POST['descricao']) ? $_POST['descricao'] : '';
    $data = date("Y-m-d H:i:s"); // Define a data atual no formato YYYY-MM-DD HH:MM:SS

    if (empty($userid) || empty($username) || empty($print) || empty($id_ticket) || empty($descricao)) {
        echo json_encode(["error" => "Todos os campos são obrigatórios."]);
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO tickets_devolution_itens (userid, username, print, id_ticket, descricao, data) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $userid, $username, $print, $id_ticket, $descricao, $data);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Item registrado com sucesso!"]);
    } else {
        echo json_encode(["error" => "Erro ao registrar o item: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
}
?>
