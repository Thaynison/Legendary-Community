<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

$servername = "legendarycommunity.com.br";
$username = "apis"; 
$password = "PO6u68GalIz5Picec33inuLEjA8O72";
$dbname = "minecraft";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

$sql = "SELECT * FROM ticket_staffs";
$result = $conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        $staffs = [];
        while ($row = $result->fetch_assoc()) {
            $staffs[] = $row;
        }
        echo json_encode($staffs);
    } else {
        echo json_encode([]);
    }
} else {
    echo json_encode(["error" => "Erro na execução da consulta: " . $conn->error]);
}

$conn->close();
?>