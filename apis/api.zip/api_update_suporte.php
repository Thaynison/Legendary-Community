<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

$servername = "legendarycommunity.com.br"; 
$username = "apis";
$password = "PO6u68GalIz5Picec33inuLEjA8O72"; 
$dbname = "minecraft"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id_ticket = isset($_POST['id_ticket']) ? $_POST['id_ticket'] : '';
    $resposta = isset($_POST['resposta']) ? $_POST['resposta'] : '';
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $data = date("Y-m-d H:i:s"); // Define a data atual no formato YYYY-MM-DD HH:MM:SS

    // Verifica se todos os campos estão preenchidos
    if (empty($id_ticket) || empty($resposta) || empty($status)) {
        echo json_encode(["error" => "Todos os campos são obrigatórios."]);
        exit();
    }

    // Buscar o usuário do ticket
    $sql = "SELECT userid FROM tickets_opens WHERE id_ticket = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id_ticket);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $userid = $row['userid']; // Pegando o userid

        // Atualizando o status do ticket
        $updateSql = "UPDATE tickets_opens SET status = ? WHERE id_ticket = ?";
        $stmtUpdate = $conn->prepare($updateSql);
        $stmtUpdate->bind_param("ss", $status, $id_ticket);
        
        if ($stmtUpdate->execute()) {
            // Inserir resposta no banco
            $stmtResposta = $conn->prepare("INSERT INTO tickets_opens_resposta (id_ticket, resposta, userid, status, data) VALUES (?, ?, ?, ?, ?)");
            $stmtResposta->bind_param("sssss", $id_ticket, $resposta, $userid, $status, $data);

            if ($stmtResposta->execute()) {
                echo json_encode(["success" => "Mensagem registrada com sucesso!"]);
            } else {
                echo json_encode(["error" => "Erro ao registrar a mensagem: " . $stmtResposta->error]);
            }
        } else {
            echo json_encode(["error" => "Erro ao atualizar o status do ticket: " . $stmtUpdate->error]);
        }

    } else {
        echo json_encode(["error" => "Nenhum ticket encontrado com o ID fornecido."]);
    }

    // Fechar os prepared statements e a conexão
    $stmt->close();
    $stmtUpdate->close();
    $stmtResposta->close();
    $conn->close();
}
?>
