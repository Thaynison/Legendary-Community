<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

// Dados de conexão com o banco de dados
$servername = "legendarycommunity.com.br";  // ou o IP do servidor MySQL
$username = "apis";         // seu nome de usuário
$password = "PO6u68GalIz5Picec33inuLEjA8O72";             // sua senha
$dbname = "minecraft";        // nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar se houve erro na conexão
if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

// Obter o ID do usuário da query string
$userid = isset($_GET['userid']) ? $_GET['userid'] : null;

if ($userid) {
    // Consultar o histórico de compras
    $sql = "SELECT * FROM tickets_emprestimo_bank WHERE userid = ? ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $userid); // "s" é o tipo de dado, string
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Se houver resultados
    if ($result->num_rows > 0) {
        $emprestimosuserid = [];
        
        while ($row = $result->fetch_assoc()) {
            $emprestimosuserid[] = $row;
        }
        
        echo json_encode($emprestimosuserid);  // Retorna o histórico de compras
    } else {
        echo json_encode(["error" => "Nenhum emprestimo encontrado para o usuário."]);
    }
} else {
    echo json_encode(["error" => "ID do usuário não fornecido."]);
}

$conn->close();
?>
