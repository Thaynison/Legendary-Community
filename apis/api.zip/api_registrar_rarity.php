<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

$servername = "legendarycommunity.com.br"; 
$username = "apis";
$password = "PO6u68GalIz5Picec33inuLEjA8O72"; 
$dbname = "minecraft"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $item = isset($_POST['item']) ? $_POST['item'] : '';
    $lore = isset($_POST['lore']) ? $_POST['lore'] : '';
    $price = isset($_POST['price']) ? $_POST['price'] : '';
    $print = isset($_POST['print']) ? $_POST['print'] : '';
    $rarity = isset($_POST['rarity']) ? $_POST['rarity'] : '';

    if (empty($item) || empty($lore) || empty($price) || empty($print) || empty($rarity)) {
        echo json_encode(["error" => "Todos os campos são obrigatórios."]);
        exit();
    }

    if (is_array($lore)) {
        $lore = implode('","', $lore);
        $lore = '"' . $lore . '"'; 
    }

    $stmt = $conn->prepare("INSERT INTO ticket_itens_rarity (item, lore, price, print, rarity) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $item, $lore, $price, $print, $rarity);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Item registrado com sucesso!"]);
    } else {
        echo json_encode(["error" => "Erro ao registrar o item: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
}
?>
