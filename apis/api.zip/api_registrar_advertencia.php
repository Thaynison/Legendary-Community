<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

$servername = "legendarycommunity.com.br"; 
$username = "apis";
$password = "PO6u68GalIz5Picec33inuLEjA8O72"; 
$dbname = "minecraft"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $userid = isset($_POST['userid']) ? $_POST['userid'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $descricao = isset($_POST['descricao']) ? $_POST['descricao'] : '';
    $regra = isset($_POST['regra']) ? $_POST['regra'] : '';
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $id_ticket = isset($_POST['id_ticket']) ? $_POST['id_ticket'] : '';
    $data = date("Y-m-d H:i:s"); // Define a data atual no formato YYYY-MM-DD HH:MM:SS

    if (empty($userid) || empty($username) || empty($descricao) || empty($status) || empty($id_ticket)) {
        echo json_encode(["error" => "Todos os campos são obrigatórios."]);
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO ticket_advertencia (userid, username, descricao, regra, status, id_ticket, data) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $userid, $username, $descricao, $regra, $status, $id_ticket, $data);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Advertencia registrada com sucesso!"]);
    } else {
        echo json_encode(["error" => "Erro ao registrar a advertencia: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
}
?>
