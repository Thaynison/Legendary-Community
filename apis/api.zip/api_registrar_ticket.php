<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

$servername = "legendarycommunity.com.br";
$username = "apis"; 
$password = "PO6u68GalIz5Picec33inuLEjA8O72";
$dbname = "minecraft";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

function gerarIdTicketUnico($conn) {
    do {
        $id_ticket = "LC_" . rand(0, 999999999);
        $result = $conn->query("SELECT id_ticket FROM tickets_opens WHERE id_ticket = '$id_ticket'");
    } while ($result->num_rows > 0); 
    return $id_ticket;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $userid = isset($_POST['userid']) ? $_POST['userid'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $titulo = isset($_POST['titulo']) ? $_POST['titulo'] : '';
    $descricao = isset($_POST['descricao']) ? $_POST['descricao'] : '';
    $print = isset($_POST['print']) ? $_POST['print'] : '';
    $id_ticket = gerarIdTicketUnico($conn);

    if (empty($userid) || empty($titulo) || empty($descricao) || empty($username) || empty($print) || empty($id_ticket)) {
        echo json_encode(["error" => "Todos os campos são obrigatórios."]);
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO tickets_opens (userid, username, titulo, descricao, print, id_ticket) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $userid, $username, $titulo, $descricao, $print, $id_ticket);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Ticket registrado com sucesso!"]);
    } else {
        echo json_encode(["error" => "Erro ao registrar o ticket: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
}
?>
