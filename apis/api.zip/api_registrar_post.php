<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

$servername = "legendarycommunity.com.br"; 
$username = "apis";
$password = "PO6u68GalIz5Picec33inuLEjA8O72"; 
$dbname = "minecraft"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $titulo = isset($_POST['titulo']) ? $_POST['titulo'] : '';
    $descricao = isset($_POST['descricao']) ? $_POST['descricao'] : '';
    $print = isset($_POST['print']) ? $_POST['print'] : '';
    $autor = isset($_POST['autor']) ? $_POST['autor'] : '';
    $data = date("Y-m-d H:i:s"); // Define a data atual no formato YYYY-MM-DD HH:MM:SS

    if (empty($titulo) || empty($descricao) || empty($autor) || empty($print)) {
        echo json_encode(["error" => "Todos os campos são obrigatórios."]);
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO ticket_posts (titulo, descricao, print, autor, data) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $titulo, $descricao, $print, $autor, $data);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Publicação registrada com sucesso!"]);
    } else {
        echo json_encode(["error" => "Erro ao registrar a publicação: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
}
?>
