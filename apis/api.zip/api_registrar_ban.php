<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

$servername = "legendarycommunity.com.br";  // ou o IP do servidor MySQL
$username = "apis";         // seu nome de usuário
$password = "PO6u68GalIz5Picec33inuLEjA8O72";         // sua senha
$dbname = "minecraft";      // nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar se houve erro na conexão
if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

// Verificar se os dados foram recebidos
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recebe os dados via POST
    $userid = isset($_POST['userid']) ? $_POST['userid'] : '';
    $ip_ban = isset($_POST['ip_ban']) ? $_POST['ip_ban'] : '';
    $discord_ban = isset($_POST['discord_ban']) ? $_POST['discord_ban'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $print = isset($_POST['print']) ? $_POST['print'] : '';
    $motivo = isset($_POST['motivo']) ? $_POST['motivo'] : '';

    // Validação simples dos dados (apenas exemplo, você pode melhorar a validação)
    if (empty($userid) || empty($ip_ban) || empty($discord_ban) || empty($username) || empty($print) || empty($motivo)) {
        echo json_encode(["error" => "Todos os campos são obrigatórios."]);
        exit();
    }

    // Preparar a consulta para evitar SQL injection
    $stmt = $conn->prepare("INSERT INTO bans (userid, ip_ban, discord_ban, username, print, motivo) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $userid, $ip_ban, $discord_ban, $username, $print, $motivo);

    // Executar a consulta
    if ($stmt->execute()) {
        echo json_encode(["success" => "Banimento registrado com sucesso!"]);
    } else {
        echo json_encode(["error" => "Erro ao registrar o banimento: " . $stmt->error]);
    }

    // Fechar a conexão
    $stmt->close();
    $conn->close();
}
?>
