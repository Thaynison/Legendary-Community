<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.legendarycommunity.com.br");  // Ou "*"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept"); // Adicionando 'Accept' pode ser necessário
header("Access-Control-Allow-Credentials: true");  // Se você precisa enviar cookies ou credenciais

date_default_timezone_set('America/Sao_Paulo');

// Dados de conexão com o banco de dados
$servername = "legendarycommunity.com.br";  // ou o IP do servidor MySQL
$username = "apis";         // seu nome de usuário
$password = "PO6u68GalIz5Picec33inuLEjA8O72";         // sua senha
$dbname = "minecraft";      // nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar se houve erro na conexão
if ($conn->connect_error) {
    die(json_encode(["error" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

// Verificar se os dados foram recebidos
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recebe os dados via POST
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $userid = isset($_POST['userid']) ? $_POST['userid'] : '';
    $codigo = isset($_POST['codigo']) ? $_POST['codigo'] : '';
    $produto = isset($_POST['produto']) ? $_POST['produto'] : '';
    $valor = isset($_POST['valor']) ? $_POST['valor'] : '';
    $data_compra = isset($_POST['data_compra']) ? $_POST['data_compra'] : '';

    // Validação simples dos dados (apenas exemplo, você pode melhorar a validação)
    if (empty($username) || empty($userid) || empty($codigo) || empty($produto) || empty($valor) || empty($data_compra)) {
        echo json_encode(["error" => "Todos os campos são obrigatórios."]);
        exit();
    }

    // Preparar a consulta para evitar SQL injection
    $stmt = $conn->prepare("INSERT INTO compras (username, userid, codigo, produto, valor, data_compra) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $username, $userid, $codigo, $produto, $valor, $data_compra);

    // Executar a consulta
    if ($stmt->execute()) {
        echo json_encode(["success" => "Compra registrada com sucesso!"]);
    } else {
        echo json_encode(["error" => "Erro ao registrar o compra: " . $stmt->error]);
    }

    // Fechar a conexão
    $stmt->close();
    $conn->close();
}
?>
